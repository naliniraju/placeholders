import { Component } from '@angular/core';
import { BreakpointObserver, Breakpoints, BreakpointState } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import {TranslateService} from '@ngx-translate/core';
//import defaultLanguage from "../../assets/i18n/te.json";

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css']
})
export class SidenavComponent {
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );
    
  constructor(private breakpointObserver: BreakpointObserver,public translate: TranslateService) {
    translate.addLangs(['en', 'te']);
    translate.setDefaultLang('te');
    // const browserLang = translate.getBrowserLang();
    // translate.use(browserLang.match(/en|te/) ? browserLang : 'en');
  }
  
  }
