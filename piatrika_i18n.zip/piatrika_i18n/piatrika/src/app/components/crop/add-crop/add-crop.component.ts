import { Component, OnInit } from '@angular/core';
import { Crop } from 'src/app/models/crop';
import { CropService } from 'src/app/services/crop/crop.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';


@Component({
  selector: 'app-add-crop',
  templateUrl: './add-crop.component.html',
  styleUrls: ['./add-crop.component.css']
})
export class AddCropComponent implements OnInit {

  crop: Crop = new Crop();
  submitted = false;
  crops: Crop[];
  // addCropForm: FormGroup;
  // crop_scientific_name: FormControl;
  // crop_name: FormControl;
  constructor(
    private cropService: CropService,
    private router: Router,
    private location: Location, private fb: FormBuilder
  ) { }
  ngOnInit() {
    // this.addCropForm = this.fb.group({
    //   crop_name: ['', [Validators.required,Validators.minLength(4),Validators.maxLength(20)]],
    //   crop_scientific_name: ['', [Validators.required,Validators.minLength(4),Validators.maxLength(20)]]
    // });
    //this.createForm();

  }
  // onSubmit() {

  // }
  // createForm(){
  //   this.crop_name = new FormControl('', [Validators.required,Validators.minLength(4),Validators.maxLength(20)]);
  //   this.crop_scientific_name = new FormControl('',[Validators.required,Validators.minLength(4),Validators.maxLength(20)]);

  // }

  //add or create crop data
  newCrop(): void {
    this.submitted = false;
    this.crop = new Crop();
  }

  addCropDetail() {
    this.submitted = true;
    this.save();
  }

  save(): void {
    console.log(this.crop);
    this.cropService.addCropDetail(this.crop)
      .subscribe();
    this.getCropDetails();
    this.router.navigate(['/crops']);
    //this.location.back();
  }
    //end of add or create crop data

//get crop data from database
  getCropDetails() {
    return this.cropService.getCropDetails()
      .subscribe(
        crops => {
          console.log(crops);
          this.crops = crops;
        }
      );
  }

}

