export class Variety {
    id:number;
    variety:string;
    variety_scientific_name:string;
    crop_id:number;
}
