export class Village {
    id:number;
    village_name:string;
    village_code:string;
    division_id:number;
}
