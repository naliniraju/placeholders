export class Bank {
    id:number;
    bank:string;
    branch_address:string;
    bank_code:string;
}
