export class ApplicationTreatment {
    id:number;
    date:Date;
    application_treatment:string;
    applied:string;
    ssp:string;
    mcp:string;
    farmer_land_village_id:number;
}
