export class FarmerRelation {
    id:number;
    related_to_csi:string;
    relationship_type:string;
    person_id:number;
}
