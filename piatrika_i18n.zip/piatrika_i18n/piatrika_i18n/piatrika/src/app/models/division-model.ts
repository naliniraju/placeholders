export class DivisionModel {
    id:number;
    division:string;
    section_code:string;
    section_name:string;
}
