import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  //Home page titles
  //assets/images/navlinks images titles should be same as piatrikanavlinks array names
  piatrikanavlinks = ['application-treatments',
    'banks', 'crops', 'division-models', 'farmers', 'farmer-banks',
    'farmer-relations', 'guarantors', 'land-villages',
    'loans', 'persons', 'phones', 'plot-visits',
    'seasons', 'varieties', 'villages'];

  constructor(
  ) { }

  ngOnInit() {
  }
}
