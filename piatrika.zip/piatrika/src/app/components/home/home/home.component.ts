import { Component, OnInit, ViewChild, ElementRef, NgZone } from '@angular/core';
// import { MapsAPILoader, MouseEvent } from '@agm/core';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  piatrikanavlinks = [{ name: 'application-treatments' },
  { name: 'banks' }, { name: 'crops' }, { name: 'division-models' }, { name: 'farmers' }, { name: 'farmer-banks' },
  { name: 'farmer-relations' }, { name: 'guarantors' }, { name: 'land-villages' },
  { name: 'loans' }, { name: 'persons' }, { name: 'phones' }, { name: 'plot-visits' },
  { name: 'seasons' }, { name: 'varieties' }, { name: 'villages' }
  ];

  constructor(
  ) { }

  ngOnInit() {
  }
}
