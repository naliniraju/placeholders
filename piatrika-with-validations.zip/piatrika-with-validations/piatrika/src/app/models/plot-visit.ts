export class PlotVisit {
    id:number;
    condition:string;
    identification:string;
    advice_given:string;
    season_id:number;
    timestamp:Date;
}
